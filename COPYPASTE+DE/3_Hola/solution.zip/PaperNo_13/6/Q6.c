#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  char str[100];
  fgets(str,sizeof(str),stdin);
  int i, count = 0;
  int n = strlen(str);
  for(i = 0; i < n; i++){
  	char c = tolower(str[i]);
  	if((toupper(c) == str[i]) && (isalpha(c))){
  		count++;
	  }
  }
  
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  
  printf("%d",count);
  
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
