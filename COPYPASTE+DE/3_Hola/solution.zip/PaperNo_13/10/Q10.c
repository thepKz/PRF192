#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int isPerfect(int n){
	int i, sum = 0;
	for(i = 1; i <= n/2; i++){
		if(n % i == 0){
			sum += i;
		}
	}
	if(sum == n){
		return 1;
	}else{
		return 0;
	}
	
}

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int i,j,n;
  int sum = 0;
	scanf("%d",&n);
	int arr[n];
	for(i = 0; i < n; i++) {
		scanf("%d",&arr[i]);
  }
  int flag = 0;
  for(i = 0; i < n; i++){
  	if(isPerfect(arr[i]) == 1){
  		sum += arr[i];
  		flag = 1;
	  }
  }
  
  
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  
  if(flag == 0){
  	printf("There is no perfect number among the %d element of the array ",n);
  }else if( flag ==1 ){
  	printf("%d",sum);
  }
  
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
