#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int i,j,n;
	scanf("%d",&n);
	int arr[n];
	for(i = 0; i < n; i++) {
		scanf("%d",&arr[i]);
  }
  
  
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  int count = 1;
  for(i = 0;i < n; i++){
  	double result = (double)arr[i] + (double)arr[i]*8/100;
  	printf("%d - %.2lf\n",count, result);
  	count++;
  }
  
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
