#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

char* replaceAll(char* source, char* subStr, char* repStr) {
	int subL = strlen(subStr);
	int repL = strlen(repStr);
	char temp[100];
	char* ptr = strstr(source,subStr);
	int i;
	while (ptr != NULL) {
		strcpy(ptr, ptr+subL);
		if(repL > 0) {
			strcpy(temp, ptr);
			strcpy(ptr+repL, temp);
			for(i = 0; i < repL; i++) {
				*(ptr+i) = repStr[i];
			}
		}
		ptr = strstr(source, subStr);
	}
}

int main() {
	system("cls");
	//INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
	char s1[100], s2[100], s3[100];
	gets(s1);
	gets(s2);
	gets(s3);
	replaceAll(s1,s2,s3);


	// Fixed Do not edit anything here.
	printf("\nOUTPUT:\n");
	//@STUDENT: WRITE YOUR OUTPUT HERE:
	printf("%s",s1);







	//--FIXED PART - DO NOT EDIT ANY THINGS HERE
	printf("\n");
	system ("pause");
	return(0);
}
