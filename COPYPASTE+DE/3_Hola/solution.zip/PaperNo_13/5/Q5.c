#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int i,j,n;
	scanf("%d",&n);
	int arr[n];
	for(i = 0; i < n; i++) {
		scanf("%d",&arr[i]);
	}

	for(i = 0; i < n - 1; i++) {
		int min_i = i;
		for(j = i + 1; j < n ; j++ ) {
			if(arr[min_i] < arr[j])
				min_i = j;
		}
		
		int temp = arr[i];
		arr[i] = arr[min_i];
		arr[min_i] = temp;
	}
  
  
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  
  for(i = 0;i < n; i++){
  	if(arr[i] % 2 == 1){
  		printf("%d ",arr[i]);
	  }
  }
  
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
