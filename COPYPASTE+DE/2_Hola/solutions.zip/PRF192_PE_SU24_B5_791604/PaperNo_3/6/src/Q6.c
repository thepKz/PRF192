#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int isConsonant(char c) {
    c = tolower(c);
    // Check if the character is a consonant (a letter that is not a vowel)
    return (isalpha(c) && c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u');
}

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  
  char s[101];  
    fgets(s, sizeof(s), stdin);

    size_t length = strlen(s);
    if (length > 0 && s[length - 1] == '\n') {
        s[length - 1] = '\0';
    }
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
    int count = 0,i;
    int isWordStart = 1;  

    for (i = 0; s[i] != '\0'; i++) {
        if (isspace(s[i])) {
            isWordStart = 1;  
        } else if (isWordStart && isConsonant(s[i])) {
            count++;
            isWordStart = 0;  
        } else {
            isWordStart = 0; 
        }
    }

    printf("%d\n", count);

  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
