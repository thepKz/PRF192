#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int n,i,j;
    scanf("%d", &n);
    
    int arr[n];
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

  
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  	int frequency[n];
    for (i = 0; i < n; i++) {
        frequency[i] = 0; 
    }
    
    for (i = 0; i < n; i++) {
        if (arr[i] % 3 == 0) {
            int alreadyCounted = 0;
            for (j = 0; j < i; j++) { 
                if (arr[i] == arr[j]) {
                    alreadyCounted = 1; 
                    break;
                }
            }
            if (!alreadyCounted) {
                int count = 0;
                for (j = i; j < n; j++) {
                    if (arr[j] == arr[i]) {
                        count++;
                    }
                }
                printf("%d-%d\n", count, arr[i]);
            }
        }
    }




  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
