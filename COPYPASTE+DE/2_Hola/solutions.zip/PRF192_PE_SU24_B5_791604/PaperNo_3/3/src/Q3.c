#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

void sort_odd_numbers(int arr[], int size) {
    int temp,i,j;
    for (i = 0; i < size - 1; i++) {
        for (j = 0; j < size - i - 1; j++) {
            if (arr[j] % 2 != 0 && arr[j + 1] % 2 != 0 && arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  
  int n,i;
  scanf("%d", &n);
  int arr[n];
  for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int odd_count = 0;
    for ( i = 0; i < n; i++) {
        if (arr[i] % 2 != 0) {
            odd_count++;
        }
    }
    int odd_numbers[odd_count];
    int index = 0;
    for (i = 0; i < n; i++) {
        if (arr[i] % 2 != 0) {
            odd_numbers[index++] = arr[i];
        }
    }
    sort_odd_numbers(odd_numbers, odd_count);
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  for (i = 0; i < odd_count; i++) {
        printf("%d\n", odd_numbers[i]);
    }
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
