#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int n,i;
  scanf("%d", &n);
  
  if (n <= 0) {
        return 1;  // Exit the program with an error code
    }
    int arr[n];
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    int sum = 0;
    int has_odd = 0;
  for (i = 0; i < n; i++) {
        if (arr[i] % 2 != 0) {
            sum += arr[i];
            has_odd = 1;  
        }
    }
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  if (has_odd) {
        printf("%d\n", sum);
    } else {
        printf("There are no odd numbers in %d elements\n", n);
    }
  
  
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
