#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  char s[101];  // Max length 100 + 1 for the null terminator
    fgets(s, sizeof(s), stdin);

    size_t length = strlen(s);
    if (length > 0 && s[length - 1] == '\n') {
        s[length - 1] = '\0';
    }
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  int capitalizeNext = 1,i;  

    for (i = 0; s[i] != '\0'; i++) {
        if (isspace(s[i])) {
            capitalizeNext = 1;  
        } else if (capitalizeNext && isalpha(s[i])) {
            s[i] = toupper(s[i]);  
            capitalizeNext = 0;    
        }
    }
  
	printf("%s\n", s);
  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
