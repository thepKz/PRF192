#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>


int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
  int rows;
  scanf("%d", &rows);
  
  if (rows <= 0) {
        return 1;  
    }
   char ch = 'A';
   int i,j;
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  for (i = 0; i < rows; i++) {
        for (j = 0; j < rows - i; j++) {
            if (ch > 'Z') {
                ch = 'A';  // Wrap around if we exceed 'Z'
            }
            printf("%c ", ch++);
        }
        printf("\n");
    }
  


  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
