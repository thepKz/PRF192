#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int main() {
  system("cls");
  //INPUT - @STUDENT:ADD YOUR CODE FOR INPUT HERE:
	int n;
    scanf("%d", &n);
    
    int arr[n],i;
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
  
  
  
  
  // Fixed Do not edit anything here.
  printf("\nOUTPUT:\n");
  //@STUDENT: WRITE YOUR OUTPUT HERE:
  int minEven = -1, maxEven = -1;
    int minIndex = -1, maxIndex = -1;

    for (i = 0; i < n; i++) {
        if (arr[i] % 2 == 0) { 
            if (minEven == -1 || arr[i] < minEven) {
                minEven = arr[i];
                minIndex = i;
            }
            if (maxEven == -1 || arr[i] > maxEven) {
                maxEven = arr[i];
                maxIndex = i;
            }
        }
    }

    if (minIndex != -1 && maxIndex != -1 && minIndex != maxIndex) {
        int temp = arr[minIndex];
        arr[minIndex] = arr[maxIndex];
        arr[maxIndex] = temp;
    }

    // Print the modified array
    for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }


  
  
  //--FIXED PART - DO NOT EDIT ANY THINGS HERE
  printf("\n");
  system ("pause");
  return(0);
}
